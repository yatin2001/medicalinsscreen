// import { EmpInsuranceDetails } from "./empinsurancedetails";

// export interface Medical{
//     empId:String,

// 	 isHaveMedicalHistory:String,

// 	 medicalHistoryDetails:String,
//      insuranceWaiverType:String,
//      empinsurancedetails:new EmpInsuranceDetails(),
// }
