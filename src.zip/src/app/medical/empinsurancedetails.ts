export interface EmpInsuranceDetails{
    
     memberName:String,
     memberAge:number,
     memberRelation:String,
     memberIdType:String,
     memberIdNumber:String,
     memberDob:String

}